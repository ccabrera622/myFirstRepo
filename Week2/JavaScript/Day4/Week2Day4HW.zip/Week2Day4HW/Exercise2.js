let myColor = ["Red", "Green", "White", "Black"];
let colorString = "";

for(let i = 0; i<myColor.length; i++)
{
	colorString += myColor[i];
}

console.log(colorString);